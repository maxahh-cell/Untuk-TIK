Perlu Visual Studio Code untuk melihat kode kode HTML, notepad bisa tapi Visual Studio Code lebih enak untuk dilihatnya. Di Visual Code kamu bisa mencoba atau run program.
index.html adalah file utama yang paling utama(namanya harus index.html untuk html).
Kode kode ini ada banyak sekali filenya tetapi 